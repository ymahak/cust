import os
from motor.motor_asyncio import AsyncIOMotorClient
import bcrypt

MONGO_URI = os.getenv("MONGO_URI")

client = AsyncIOMotorClient(MONGO_URI)
db = client["ai_customer_support"]

users_collection = db["users"]
escalations_collection = db["escalations"]


async def create_user(username: str, password: str, role: str):
    hashed_password = bcrypt.hashpw(
        password.encode("utf-8"), bcrypt.gensalt()
    ).decode("utf-8")

    user = {
        "username": username,
        "password": hashed_password,
        "role": role,
    }

    await users_collection.insert_one(user)


async def verify_user(username: str, password: str):
    user = await users_collection.find_one({"username": username})
    if not user:
        return None

    if not bcrypt.checkpw(
        password.encode("utf-8"), user["password"].encode("utf-8")
    ):
        return None

    return user


async def get_user_by_username(username: str):
    return await users_collection.find_one({"username": username})
