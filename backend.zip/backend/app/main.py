from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import Optional
import uvicorn

# ---------- Internal Imports ----------
from app.auth.jwt import verify_token, create_token
from app.routes.chat import router as chat_router
from app.routes.hitl import router as hitl_router
from app.routes.monitoring import router as monitoring_router
from app.database.mongo import (
    connect_db,
    create_user,
    verify_user,
    get_user_by_username,
)
from app.monitoring.logger import setup_logger

# ---------- App Initialization ----------
app = FastAPI(
    title="AI Customer Support",
    version="1.0.0",
    description="Multi-agent AI customer support system with HITL"
)

# ---------- CORS ----------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- Logger ----------
logger = setup_logger()

# ---------- Security ----------
security = HTTPBearer()

# ---------- Models ----------
class User(BaseModel):
    username: str
    password: str


class SignupRequest(BaseModel):
    username: str
    password: str
    role: Optional[str] = "user"


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

# ---------- Startup Event ----------
@app.on_event("startup")
async def startup_event():
    await connect_db()
    logger.info("✅ Database connected successfully")

# ---------- Routers ----------
app.include_router(chat_router, prefix="/api")
app.include_router(hitl_router, prefix="/api")
app.include_router(monitoring_router, prefix="/api")

# ---------- Root ----------
@app.get("/")
async def root():
    return {
        "message": "AI Customer Support API",
        "status": "running"
    }

# ---------- AUTH: SIGNUP ----------
@app.post("/api/auth/signup", response_model=dict)
async def signup(signup_data: SignupRequest):
    # Validate role
    if signup_data.role not in ["user", "agent", "admin"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid role. Must be user, agent, or admin"
        )

    # Validate username
    if len(signup_data.username) < 3:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username must be at least 3 characters long"
        )

    # Validate password
    if len(signup_data.password) < 6:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 6 characters long"
        )

    # Check if user already exists
    existing_user = await get_user_by_username(signup_data.username)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username already exists"
        )

    # Create user
    user = await create_user(
        username=signup_data.username,
        password=signup_data.password,
        role=signup_data.role
    )

    logger.info(f"🆕 User signed up: {user['username']}")

    return {
        "message": "User created successfully",
        "username": user["username"],
        "role": user["role"]
    }

# ---------- AUTH: LOGIN ----------
@app.post("/api/auth/login", response_model=TokenResponse)
async def login(user: User):
    user_data = await verify_user(user.username, user.password)
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password"
        )

    token = create_token({
        "username": user_data["username"],
        "role": user_data["role"]
    })

    logger.info(f"🔑 User logged in: {user_data['username']}")

    return {
        "access_token": token,
        "token_type": "bearer"
    }

# ---------- AUTH: CURRENT USER ----------
@app.get("/api/auth/me")
async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    payload = verify_token(credentials.credentials)
    return {
        "username": payload["username"],
        "role": payload["role"]
    }

# ---------- HEALTH CHECK ----------
@app.get("/api/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "ai-customer-support"
    }

# ---------- Run ----------
if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
